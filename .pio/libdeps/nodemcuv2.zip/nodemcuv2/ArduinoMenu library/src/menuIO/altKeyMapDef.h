/* -*- C++ -*- */

#ifndef RSITE_ARDUINO_MENU_KEYMAP
  #define RSITE_ARDUINO_MENU_KEYMAP

struct keyMap {
  int8_t pin;
  uint8_t code;
  uint8_t mode;
};

#endif
