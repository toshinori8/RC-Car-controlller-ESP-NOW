#include "cancelField.h"

bool cancelFieldOptions::quitOnEsc=true;
bool cancelFieldOptions::accelSendEsc=true;
